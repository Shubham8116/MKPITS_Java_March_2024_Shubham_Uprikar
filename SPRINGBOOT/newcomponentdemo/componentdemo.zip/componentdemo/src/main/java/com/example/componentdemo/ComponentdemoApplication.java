package com.example.componentdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComponentdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComponentdemoApplication.class, args);
	}

}
