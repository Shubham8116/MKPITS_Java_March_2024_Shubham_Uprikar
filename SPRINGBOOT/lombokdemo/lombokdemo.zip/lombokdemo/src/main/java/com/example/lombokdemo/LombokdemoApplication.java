package com.example.lombokdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LombokdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LombokdemoApplication.class, args);
	}

}
