package com.example.lombokdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LombokdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
